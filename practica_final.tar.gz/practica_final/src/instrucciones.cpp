#include <iostream>
#include "instrucciones.h"
using namespace std;

instrucciones::instrucciones(){}

instrucciones::instrucciones (acciones& accions){
	acc = accions;
}

void instrucciones::setAcciones (acciones& accions){
	acc = accions;
}

acciones instrucciones::acc = acciones();

void instrucciones::setDatos (ArbolBinario<string>& dat){
	datos = dat;
}

ArbolBinario<string> instrucciones::getDatos() const{
	return datos;
}

// Operador >>
istream & operator >> (istream & is, instrucciones & instr){
	stack < ArbolBinario<string> > p;
	string accion, ingrediente;
	char caracter;

	while(is >> accion){
		is.get(caracter);

		ArbolBinario<string> arbol(accion);
//cout << "\nAccion: " << accion << " " << instr.acc[accion] << endl;

		if (instr.acc[accion] == '1'){
//cout << "\tEntra en aridad 1" << endl;
			if (caracter == '\n'){				// Caracter es '\n'

				arbol.Insertar_Hi(arbol.getRaiz(), p.top());
				p.pop();

			}

			else {						// Caracter es ' '
				getline(is, ingrediente, '\n');

//cout <<"\tAccion ingrediente: "<< accion << "|" << ingrediente << endl;
				arbol.Insertar_Hi(arbol.getRaiz(), ingrediente);
			}
		}

		if (instr.acc[accion] == '2'){
//cout << "\tEntra en aridad 2" << endl;
			if (caracter == '\n'){

				arbol.Insertar_Hd(arbol.getRaiz(), p.top());
				p.pop();

				arbol.Insertar_Hi(arbol.getRaiz(), p.top());
				p.pop();

			}

			else {

				getline(is, ingrediente, '\n');

//cout <<"\tAccion ingrediente: "<< accion << "|" << ingrediente << endl;

				arbol.Insertar_Hd(arbol.getRaiz(), ingrediente);

				arbol.Insertar_Hi(arbol.getRaiz(), p.top());
				p.pop();

			}

		}

		p.push(arbol);
	}

	instr.datos = p.top();
	p.pop();

//instr.datos.RecorridoPostOrden(cout);

	return is;
}



// Operador <<
ostream & operator << (ostream & out, const instrucciones & instr){

	string ingrediente;
	ArbolBinario<string>::postorden_iterador it = instr.datos.beginpostorden();

	while (it != instr.datos.endpostorden()){

		if ( instr.acc[(*it)] == 0){			// Si no tiene aridad es un ingrediente (operator [] devuelve el unsigned char 0)
								// Al ser instr constante se usará el const operator [] de acciones
//cout << "entra en primer if: ingrediente" << endl;
			ingrediente = " " + *it;
		}
		else {						// Si es una acción de aridad 1 o 2
//cout << "entra en segundo if: aridad 1 o 2" << endl;
			out << *it << ingrediente << endl;
			ingrediente = "";			// Dejamos el ingrediente vacío para que no vuelva a aparecer si este se refiere al ingr. anterior
		}

		++it;
	}

	return out;

}

